# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC **Schema Defining**

# COMMAND ----------

my_schema = """order_id STRING,
        timestamp STRING,
        customer STRUCT<
          customer_id: INT,
          name: STRING,
          email: STRING,
          address: STRUCT<
            city: STRING,
            postal_code: STRING,
            country: STRING
          >
        >,
        items ARRAY<STRUCT<
          item_id: STRING,
          product_name: STRING,
          quantity: INT,
          price: DOUBLE
        >>,
        payment STRUCT<
          method: STRING,
          transaction_id: STRING
        >,
        metadata ARRAY<STRUCT<
          key: STRING,
          value: STRING
        >>"""

# COMMAND ----------

# MAGIC %md
# MAGIC **Read Streaming Data**

# COMMAND ----------



## Reading stream data
df = spark.readStream.format("json")\
    .schema(my_schema)\
    .option("multiline", True)\
    .load("/Volumes/workspace/stream/streaming/jsonsrc")

## Transformations

df = df.select("metadata","items","order_id","timestamp","customer.customer_id","customer.name","customer.email","customer.address.city","customer.address.postal_code","customer.address.country","payment.method","payment.transaction_id")

df = df.withColumn("items",explode_outer("items"))
df = df.select("metadata","order_id","timestamp","customer_id","name","email","city","postal_code","country","method","transaction_id","items.item_id","items.price","items.quantity","items.product_name")
df = df.withColumn("metadata",explode_outer("metadata"))
df = df.select("order_id","timestamp","customer_id","name","email","city","postal_code","country","method","transaction_id","item_id","price","quantity","product_name","metadata.key","metadata.value")




# COMMAND ----------

# MAGIC %md
# MAGIC **Writing Stream Data**

# COMMAND ----------

df.writeStream.format("delta")\
    .outputMode("append")\
    .option("path", "/Volumes/workspace/stream/streaming/jsonsink/data")\
    .option("checkpointLocation", "/Volumes/workspace/stream/streaming/jsonsink/checkpoint")\
    .trigger(once=True)\
    .start()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/Volumes/workspace/stream/streaming/jsonsink/data`

# COMMAND ----------

# MAGIC %md
# MAGIC **Archiving**

# COMMAND ----------

dbutils.fs.mkdirs("/Volumes/workspace/stream/streaming/jsonsinknew")

# COMMAND ----------



## Reading stream data
df = spark.readStream.format("json")\
    .schema(my_schema)\
    .option("multiline", True)\
    .option("cleanSource","archive")\
    .option("sourceArchiveDir","/Volumes/workspace/stream/streaming/jsonsrcarchive")\
    .load("/Volumes/workspace/stream/streaming/jsonsrcnew")

## Transformations

df = df.select("metadata","items","order_id","timestamp","customer.customer_id","customer.name","customer.email","customer.address.city","customer.address.postal_code","customer.address.country","payment.method","payment.transaction_id")

df = df.withColumn("items",explode_outer("items"))
df = df.select("metadata","order_id","timestamp","customer_id","name","email","city","postal_code","country","method","transaction_id","items.item_id","items.price","items.quantity","items.product_name")
df = df.withColumn("metadata",explode_outer("metadata"))
df = df.select("order_id","timestamp","customer_id","name","email","city","postal_code","country","method","transaction_id","item_id","price","quantity","product_name","metadata.key","metadata.value")




# COMMAND ----------

df.writeStream.format("delta")\
    .outputMode("append")\
    .option("path", "/Volumes/workspace/stream/streaming/jsonsinknew/data")\
    .option("checkpointLocation", "/Volumes/workspace/stream/streaming/jsonsinknew/checkpoint")\
    .trigger(once=True)\
    .start()
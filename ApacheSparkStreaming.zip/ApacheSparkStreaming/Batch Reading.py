# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC **READ JSON DATA(BATCH)**

# COMMAND ----------

df = spark.read.format("json")\
    .option("inferSchema", "true")\
    .option("multiline", "true")\
    .load("/Volumes/workspace/stream/streaming/jsonsrc")

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **flatten the json data**

# COMMAND ----------

df = df.select("metadata","items","order_id","timestamp","customer.customer_id","customer.name","customer.email","customer.address.city","customer.address.postal_code","customer.address.country","payment.method","payment.transaction_id")

df = df.withColumn("items",explode_outer("items"))
df.display()

# COMMAND ----------

df = df.select("metadata","order_id","timestamp","customer_id","name","email","city","postal_code","country","method","transaction_id","items.item_id","items.price","items.quantity","items.product_name")

df.display()

# COMMAND ----------


df = df.withColumn("metadata",explode_outer("metadata"))
df = df.select("order_id","timestamp","customer_id","name","email","city","postal_code","country","method","transaction_id","item_id","price","quantity","product_name","metadata.key","metadata.value")
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC **Final Dataframe**

# COMMAND ----------

df=df.select("order_id","timestamp","customer_id","name","email","city","postal_code","country","method","transaction_id","item_id","price","quantity","product_name","key","value")
df.display()